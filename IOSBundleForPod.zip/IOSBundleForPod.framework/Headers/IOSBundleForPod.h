//
//  IOSBundleForPod.h
//  IOSBundleForPod
//
//  Created by admin on 06/08/21.
//

#import <Foundation/Foundation.h>

//! Project version number for IOSBundleForPod.
FOUNDATION_EXPORT double IOSBundleForPodVersionNumber;

//! Project version string for IOSBundleForPod.
FOUNDATION_EXPORT const unsigned char IOSBundleForPodVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IOSBundleForPod/PublicHeader.h>


